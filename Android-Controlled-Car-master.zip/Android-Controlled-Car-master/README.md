# Android-Controlled-Car
A wireless car which is controlled by android smartphone using bluetooth 
![ScreenShot](https://github.com/Superhuman07/Android-Controlled-Car/blob/master/IMG_20160116_135014259.jpg)
