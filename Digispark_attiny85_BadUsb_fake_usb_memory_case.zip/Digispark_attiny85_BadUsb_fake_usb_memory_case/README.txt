                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2347216
Digispark attiny85 BadUsb fake usb memory case by Prospect3dlab is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

https://www.youtube.com/watch?v=fGmGBa-4cYQ 
In this video Seytonic explain how you can use DigiSpark as 1$ usb virtual keyboard for doing all sorts of stuff. I designed and tried this case which make ordinary DigiSpark to look like full size USB memory. Just for an visual expirience. 

If you support open source electronic and all hard engineering behind every piece of open source electronic which you are using right now, support Seytonic in his project Malduino:
https://malduino.com/

IM NOT RESPONSABLE FOR ANY ILLEGAL ACTIVITY WHICH YOU CAN USE THIS FOR. YOUR CALLS ARE ONLY YOURS AND I CANNOT MAKE ANYONE DO OR DO NOT DO ANYTHING, IM JUST DESIGNER OF THIS CASE AND ITS UP TO YOU WHY YOU WILL PRINT AND USE IT.

# Print Settings

Printer: Acrylic prusa
Rafts: No
Supports: No
Resolution: 0.3mm
Infill: 25%

Notes: 
Print flat without any support or rafts. You can use brims if you want, but its flat print so you will not have any problem with wrapping. I used 100% infill just for the sake of genuinity of print itself, but you can use 25% with ease.
You will also probably need to file little bit sides of digispark, because of sharp edges...not much, to not damage board itself, but just little bit to make edges smoother and that can fit into case. When you print, glue down lid with some glue for plastic